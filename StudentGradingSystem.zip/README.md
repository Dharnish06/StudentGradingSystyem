# Student Grading System

This is a basic Java console application for managing student records and calculating grades based on marks.

## Features
- Input student name, roll number, and subject marks
- Calculate average marks
- Assign grades based on the average
- Display a student report card

## Grading Criteria
- A: 90-100
- B: 80-89
- C: 70-79
- D: 60-69
- F: Below 60

## How to Run
1. Compile:
   ```bash
   javac -d out src/com/grading/*.java
   ```

2. Run:
   ```bash
   java -cp out com.grading.StudentGradingSystem
   ```

## Directory Structure
```
StudentGradingSystem/
├── src/
│   └── com/
│       └── grading/
│           ├── Student.java
│           └── StudentGradingSystem.java
├── README.md
└── .gitignore
```

## Author
Made by [Your Name]
