package com.grading;

import java.util.Scanner;

public class StudentGradingSystem {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter number of students: ");
        int n = Integer.parseInt(sc.nextLine());

        Student[] students = new Student[n];

        for (int i = 0; i < n; i++) {
            System.out.println("\nEnter details for Student " + (i + 1) + ":");
            System.out.print("Name: ");
            String name = sc.nextLine();
            System.out.print("Roll Number: ");
            int rollNumber = Integer.parseInt(sc.nextLine());

            int[] marks = new int[5];
            for (int j = 0; j < 5; j++) {
                System.out.print("Marks for Subject " + (j + 1) + ": ");
                marks[j] = Integer.parseInt(sc.nextLine());
            }

            students[i] = new Student(name, rollNumber, marks);
        }

        System.out.println("\n========== Student Report Cards ==========");
        for (Student student : students) {
            student.displayReport();
        }

        sc.close();
    }
}
