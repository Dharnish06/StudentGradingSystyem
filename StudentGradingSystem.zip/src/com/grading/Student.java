package com.grading;

public class Student {
    private String name;
    private int rollNumber;
    private int[] marks;
    private double average;
    private char grade;

    public Student(String name, int rollNumber, int[] marks) {
        this.name = name;
        this.rollNumber = rollNumber;
        this.marks = marks;
        this.average = calculateAverage();
        this.grade = calculateGrade();
    }

    private double calculateAverage() {
        int total = 0;
        for (int mark : marks) {
            total += mark;
        }
        return total / (double) marks.length;
    }

    private char calculateGrade() {
        if (average >= 90) return 'A';
        else if (average >= 80) return 'B';
        else if (average >= 70) return 'C';
        else if (average >= 60) return 'D';
        else return 'F';
    }

    public void displayReport() {
        System.out.println("\n--- Student Report ---");
        System.out.println("Name       : " + name);
        System.out.println("Roll Number: " + rollNumber);
        for (int i = 0; i < marks.length; i++) {
            System.out.println("Subject " + (i + 1) + ": " + marks[i]);
        }
        System.out.printf("Average    : %.2f\n", average);
        System.out.println("Grade      : " + grade);
    }
}
